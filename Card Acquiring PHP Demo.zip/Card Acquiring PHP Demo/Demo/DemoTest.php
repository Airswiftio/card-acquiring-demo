<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once '../SecurityUtil/RsaSignatureUtils.php';
require_once '../Util/HttpClient.php';
require_once '../Util/Tools.php';

$PrivateKey = "MIIEpAIBAAKCAQEAwOYYvyK56a310nb3MyObsgQfYINHpJ81VmJzP8yFHq2NSbm39zF90/rF94QH2CE266PPsef7/JyoiSWjEBVcOWdXg7YKeCiw8mEtCafysrBllpazgM9nNO9QjBzdc8vQ5NbJStd2uPhpPShfsJw/y760xKu7CFAs8dsAZd4BUc9qLBQ82wnAWjSfwyZbpZNr3A6sl7PuAHmlt3ZQjE7Ul2CbjwTlnrTGCmPaqLsWiXTkOWJbumNpblNJYY8zCthL6DvPb3I00kz9eC8LcVM4c1yN0bg5PUIz+6NjTyJAcXyncxylrUe6bWpihxV3geUZBNIdGnTlyOu+5pOUlRji0QIDAQABAoIBAQC0OMY6HYmxB7S59Cg1ATm/8hYWp9DRv2Wn1cdzffOJnAB7Nybnrreuy4cWH6bsiOu08JFl2CYX942GxUE6D5rgjuq2xee2J95aNexMLzuTMzdWoGoJGL2GOWj53yYPwAblJr9eSzxCyOQaHZR5fyIji4N8lC3kMHQtar1Ob0KwWQXT+pcwNE2s2b2LlV9aVTe+qC5FWjFcQgt1Px6nOkwzoQ+BLCOBkULfpVOJ+ot6H/HVvo/zzJEX+D5DDRQIb4Rk8UAZwngaPHl8whzPCpJQWUTK7hkSNfYPKChM99/STXkvd6QJXPLt+OAFG4YCLrRo20Ojziygsk1T0wRt/MuBAoGBAPT7dRjFmUq2vedbpXt01tHwk01LSsHCCSk7L+2sG1JxM//pcyrqZDBWSHcAmdfc9TZDaobfKXhBpdyp5lYW0IJaNTZP9+JOCLTv2hhxTNM7KUE1AMaQ9Y9iEmZGV8uLNil1APJGSfCgduRdKPR55qu4UUrkxFdWyGY0S+a4Gh7pAoGBAMmS/UyxucCQl+YUdRknKPI9KVI/Wx8wZvi6z7B0x7Nb+lb8cVL1la1sKQXJ782XxaCKjsHF4E6XcfQqqe3L0eIJW2zmo7bhu9n7noTm/fPabFsvqCMkPymVRHZi1u3nbqgVIiqn3glwc9TeV6pEPQv+Ooun4XjI7ChheBGId8OpAoGBAKg6dTLJnnab/tR9LqoUleAc4EpXxcJASKIzrrn7UdfPPPIjkZ6KzroSxjhSBVMivJDCwshTPtsB2bAqS64ahJy+7YOabpLNG1WEz7OxOhxjp/TLPPkeWkJYCmKJM4jm1A6r9jZo5iWDS6GOB626eBi7vbc8WUfQpFTq3KRXEDjhAoGASHCKlwVHu+w6qnSvoFpyXJuePfCGzq6WUszP1pohKlPjo18VWrrnD2vPUkU/6KKiYw9oPjreYWALk7PBXbPhuVmjgX9hVlfJKo1CaoCYwwm75wk5Y2ejS05ZTDI5C0YgfkcaADpTkRDYj6dX2disF6NFZuruHHoYZGqiu6pPYAECgYAod/s90kKQEYmdZObfqS9/89NOVKrARyMuu2MrUd5tbQjOUkQLA2BU2WVtRexE4CINswq0tzr/edtIuFbMgqMPpdjgubKzCp6Zz4t3w8skYwRQUNaUi1G+aAIPndShSI2s+BoWOfItQBwyYQSsFLuJ+l+OY4ZzL+meo+qdWSRlQg==";
$PublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwOYYvyK56a310nb3MyOb sgQfYINHpJ81VmJzP8yFHq2NSbm39zF90/rF94QH2CE266PPsef7/JyoiSWjEBVc OWdXg7YKeCiw8mEtCafysrBllpazgM9nNO9QjBzdc8vQ5NbJStd2uPhpPShfsJw/ y760xKu7CFAs8dsAZd4BUc9qLBQ82wnAWjSfwyZbpZNr3A6sl7PuAHmlt3ZQjE7U l2CbjwTlnrTGCmPaqLsWiXTkOWJbumNpblNJYY8zCthL6DvPb3I00kz9eC8LcVM4 c1yN0bg5PUIz+6NjTyJAcXyncxylrUe6bWpihxV3geUZBNIdGnTlyOu+5pOUlRji 0QIDAQAB";

$Post_Param = array();
$Post_Param["merchantId"] = "26";//商户编号
$Post_Param["merchantOrderId"] = "";//订单币种
$Post_Param["merchantOrderTime"] = Tools::getTime();//getTime
$Post_Param["orderCurrency"] = "USD";//
$Post_Param["orderAmount"] = "1";//订单金额
$Post_Param["productDetail"] = "线上外卡直连测试";//商品详情
$Post_Param["serverUrl"] = "www.baidu.com";//回调地址
$Post_Param["browserUrl"] = "www.baidu.com";//浏览器返回地址
$Post_Param["cardType"] = "MASTERCARD";//卡类型:VISA  MASTERCARD
$Post_Param["firstName"] = "antony";//
$Post_Param["lastName"] = "li";//
$Post_Param["cardNo"] = "5554748800001870";//卡号
$Post_Param["cardExpMonth"] = "11";//卡有效月份格式为MM
$Post_Param["cardExpYear"] = "2024";//卡有效年份 格式为yyyy
$Post_Param["cardCcv"] = "343";//CVV
$Post_Param["country"] = "HK";//国家代码
$Post_Param["state"] = "HK";//州/省份
$Post_Param["city"] = "Hong Kong";//城市
$Post_Param["postcode"] = "427100";//邮编
$Post_Param["phone"] = "00915492";//电话
$Post_Param["address"] = "WORKSHOP C5,15F,TML TOWER,NO.3 HOI SHING";//
$Post_Param["email"] = "yangwenxue@alchemytech.io";//EMAIL地址


$Sort_Str =  Tools::SortAndOutValueString($Post_Param);
echo "排序：".$Sort_Str."<br>";
$Sign = RsaSignatureUtils::Sign($Sort_Str, $PrivateKey);
echo "签名：".$Sign."<br>";

$Post_Param["sign"] = $Sign;//签名

$Return_Str = HttpClient::Post($Post_Param, "https://globalcard.airswift.io/tra/online/quickPay", "json");

echo "返回结果：".$Return_Str."<br>";




