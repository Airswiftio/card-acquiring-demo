<?php
/**
 * Company: www.baofu.com
 * @author dasheng(大圣)
 * @date 2023年2月11日
 */
 class RsaSignatureUtils{
     /**
      * 
      * @param type $Data  原数据
      * @param type $PfxPath 私钥路径
      * @param type $Pwd 私钥密码
      * @return type
      * @throws Exception
      * @author 大圣 <dasheng@baofu.com>
      */
     public static function Sign($Sign_Data,$Private_Key_Str)
    {         
        if(empty($Private_Key_Str)) {
           throw new Exception("私钥为空！");
        }
        $Format_Key = "-----BEGIN RSA PRIVATE KEY-----\n".chunk_split($Private_Key_Str, 64,"\n").'-----END RSA PRIVATE KEY-----';//格式化PKCS1
        $Read_Key=array();
        $BinarySignature=NULL;
        if(($Read_Key = openssl_get_privatekey($Format_Key))){
            if (openssl_sign($Sign_Data, $BinarySignature, $Read_Key, OPENSSL_ALGO_MD5)) {
                openssl_free_key($Read_Key);
                return base64_encode($BinarySignature);
            } else {
                throw new Exception("加签异常！");
            }
        }else{
            throw new ErrorException("私钥不正确，无法正常解析");
        }
    }


    /**
     * 验证签名自己生成的是否正确
     *
     * @param string $Data 签名的原文
     * @param string $CerPath  公钥路径
     * @param string $SignaTure 签名
     * @return bool
     * @author 大圣 <dasheng@baofu.com>
     */
    public static function VerifySign($Src_Data,$Public_Key_Str,$SignaTure)
    {
        if(empty($Public_Key_Str)) {
           throw new Exception("公钥为空！");
        }
        $Format_Key = "-----BEGIN PUBLIC KEY-----\n".chunk_split($Public_Key_Str,64,"\n")."-----END PUBLIC KEY-----";//格式化公钥字串        
        $Certs = openssl_get_publickey($Format_Key);
        $ok = openssl_verify($Src_Data, base64_decode($SignaTure), $Certs,OPENSSL_ALGO_MD5);
        if ($ok == 1) {
            return true;
        }
        return false;
    }
 }