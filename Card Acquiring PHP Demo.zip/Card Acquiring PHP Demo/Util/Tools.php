<?php

class Tools{
    
    /**
     * 生成时间戳
     * @return type
     */
    public static function getTransid(){
        return strtotime(date('Y-m-d H:i:s',time()));
    }
    /**
     * 生成四位随机数
     * @return type
     */
    public static function getRand4(){
        return rand(1000,9999);
    }
    /**
     * 生成四位随机数
     * @return type
     */
    public static function getTime($datef="Y-m-d H:i:s"){
        return date($datef,time());
    }
    
    /**
     * 排序输出k=v&k1=v1.....格式
     * @param type $DArray
     * @return type
     */
    public static function SortAndOutString($DArray) 
    {
        $TempData = array();
        foreach ($DArray As $Key => $Value){
            if(!self::isBlank($Value)){
                $TempData[$Key] = $Value;
            }
        }
        ksort($TempData);//排序
        return http_build_query($TempData);
    }
    
    /**
     * 值拼接value1value2.......
     * @param type $DArray
     * @return type
     */
    public static function SortAndOutValueString($DArray) 
    {
        $TempData = array();
        $Values_Str="";
        foreach ($DArray As $Key => $Value){
            if(!self::isBlank($Value)){
                $TempData[$Key] = $Value;
            }
        }
        ksort($TempData);//排序        
        foreach ($TempData As $Key => $Value){
            $Values_Str .= $Value;
        }        
        return $Values_Str;
    }
    
    /**
     * 判断是否空值
     * @param type $Strings
     * @return boolean
     */
    public static function isBlank($Strings){
        $Strings = trim($Strings);
        if((empty($Strings)||($Strings == null))&&(strlen($Strings) <= 0)){
            return true;
        }else{
            return FALSE;
        }
    }
    
    /**
     * 删除数组元素
     * @param type $data
     * @param type $key
     * @return type
     */
    public static function array_remove($data, $key){  
        if(!array_key_exists($key, $data)){  
            return $data;  
        }  
        $keys = array_keys($data);  
        $index = array_search($key, $keys);  
        if($index !== FALSE){  
            array_splice($data, $index, 1);  
        }  
        return $data;    
    }
    /**
     * 获取信封中的key值
     * @param type $Strings
     * @return type
     * @throws Exception
     */
    public static function getAesKey($Strings){
        $KeyArray = explode("|",$Strings);
        if(count($KeyArray) == 2){
            $KeyArray[1]=trim($KeyArray[1]);
            if(!empty($KeyArray[1])){
    		return $KeyArray[1];
            }else{
    		throw new Exception("Key is Null!");
            }
        }else{
            throw new Exception("Data format is incorrect!"); 
        }
    }
}